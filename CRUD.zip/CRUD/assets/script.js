
var app = new Vue({

  el: "#app",
  data: {
    showInputModal: false,
    showUpdateModal: false,
    showAlertModal: false,
    showConfirmModal: false,
    loading: false,
    message: "",
    index: 0,
    country: "",
    code: "",
    id: 0,
    createdAt: "",
    countries: [{
      id: "123",
      name: "USA",
      code: "4543",
      createdAt: "2019-07-12T08:54:16.260Z"
    }],
    editInput: []
  },

  methods: { 
    
    showAlert: function(msg) {
      this.showAlertModal = true;
      this.message = msg;
    },

    showConfirm: function(index, msg) {
      this.showConfirmModal = true;
      this.message = msg;
      this.index = index;
    },

    addCountry() {
      if (this.validate(this.country, this.code)) {
        this.loading = true;
        axios.post("https://reqres.in/api/users", {
          country: this.country,
          code: this.code
        })
        .then((response) => {
            this.loading = false;
            this.country = this.code = "";

            this.countries.push({
              name: response.data.country,
              code: response.data.code,
                id: response.data.id,
              createdAt: moment(response.data.createdAt)
                          .format('ddd MMM DD, YYYY @ h:mm A')
            });
            
            this.showAlert(response.data.country + " was successfully added.");
        })
        .catch(function (error) {
            this.loading = false;
            this.showAlert("Oh no! " + error);
        });
      }
    },

    viewUpdateModal(index) {
      this.index = index;
      this.editInput = this.countries[index];
      this.showUpdateModal = true;
    },

    updateCountry(index) {
      if (this.validate(this.editInput.name, this.editInput.code)) {
        this.loading = true;
        axios.post("https://reqres.in/api/users/2", {
          country: this.editInput.name,
          code: this.editInput.code
        })
        .then((response) => {
            this.loading = false;
            this.editInput.name = this.editInput.code = "";

            this.countries.push({
              name: response.data.country,
              code: response.data.code,
                id: this.countries[index].id,
              createdAt: this.countries[index].createdAt
            });
            this.countries.splice(index, 1);
            showUpdateModal = false;
            this.showAlert("Success! Updated at: "+moment(response.data.createdAt)
                                                                        .format('ddd MMM DD, YYYY @ h:mm A'));
        })
        .catch(function (error) {
            // this.showAlert("Oh no! " + error);
            this.loading = false;
            alert(error)
        });
      }
    },

    deleteCountry(index) {
      this.countries.splice(index, 1);
      this.showConfirmModal = false;
      this.showAlert("Country successfully deleted!");
    },

    validate(country, code) {
      if (country == "" || code == "") {
        this.showInputModal = false;
        this.showUpdateModal = false;
        this.showAlert("Please Complete all entries");
        return false;
      } else {
        return true;
      }
    },

    // loadCountry() {
    //   axios.get("https://reqres.in/api/users?page=2")

    //   .then((response) => {
    //       this.showAlert(response.data);
    //   })
    //   .catch(function (error) {
    //       this.showAlert("Oh no! " + error);
    //   });
    // }
    
  },

  // mounted() {
  //   this.loadCountry();
  // } 

});
